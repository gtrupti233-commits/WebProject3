-- IoT-Based Energy Monitoring Dashboard Database Script

-- Create database
CREATE DATABASE IF NOT EXISTS iot_energy_db;

-- Use the database
USE iot_energy_db;

-- Create energy_readings table
CREATE TABLE IF NOT EXISTS energy_readings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    zone_name VARCHAR(50) NOT NULL,
    energy_usage DECIMAL(10,2) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create users table for login system
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') NOT NULL
);

-- Insert sample users
INSERT INTO users (username, password, role) VALUES
('admin', 'admin123', 'admin'),
('user', 'user123', 'user');

-- Create energy_anomalies table for logging anomalies
CREATE TABLE IF NOT EXISTS energy_anomalies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    zone_name VARCHAR(50) NOT NULL,
    anomaly_type VARCHAR(50) NOT NULL, -- e.g., 'spike', 'failure'
    energy_usage DECIMAL(10,2) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create alerts_log table for logging alerts
CREATE TABLE IF NOT EXISTS alerts_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    zone_name VARCHAR(50) NOT NULL,
    alert_level VARCHAR(20) NOT NULL, -- 'normal', 'moderate', 'high'
    energy_usage DECIMAL(10,2) NOT NULL,
    message TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add indexes for performance
CREATE INDEX idx_energy_readings_timestamp ON energy_readings (timestamp);
CREATE INDEX idx_energy_readings_zone ON energy_readings (zone_name);
CREATE INDEX idx_energy_anomalies_timestamp ON energy_anomalies (timestamp);
CREATE INDEX idx_alerts_log_timestamp ON alerts_log (timestamp);
