package com.example.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * Dialog for configuring live data settings, such as refresh interval.
 */
public class LiveDataSettingsDialog extends JDialog {
    private int refreshInterval; // in seconds
    private JTextField intervalField;
    private JSlider intervalSlider;
    private boolean confirmed = false;

    public LiveDataSettingsDialog(JFrame parent, int currentInterval) {
        super(parent, "Live Data Settings", true);
        this.refreshInterval = currentInterval;

        setSize(400, 250);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        // Main panel
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Label
        JLabel label = new JLabel("Refresh Interval (seconds):");
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        mainPanel.add(label, gbc);

        // Slider
        intervalSlider = new JSlider(1, 60, refreshInterval);
        intervalSlider.setMajorTickSpacing(10);
        intervalSlider.setMinorTickSpacing(5);
        intervalSlider.setPaintTicks(true);
        intervalSlider.setPaintLabels(true);
        intervalSlider.addChangeListener(e -> {
            refreshInterval = intervalSlider.getValue();
            intervalField.setText(String.valueOf(refreshInterval));
        });
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(intervalSlider, gbc);

        // Text field for manual input
        intervalField = new JTextField(String.valueOf(refreshInterval), 5);
        intervalField.setHorizontalAlignment(SwingConstants.CENTER);
        intervalField.addActionListener(e -> {
            try {
                int value = Integer.parseInt(intervalField.getText());
                if (value >= 1 && value <= 60) {
                    refreshInterval = value;
                    intervalSlider.setValue(value);
                } else {
                    JOptionPane.showMessageDialog(this, "Interval must be between 1 and 60 seconds.");
                    intervalField.setText(String.valueOf(refreshInterval));
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number.");
                intervalField.setText(String.valueOf(refreshInterval));
            }
        });
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.NONE;
        mainPanel.add(intervalField, gbc);

        add(mainPanel, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton okButton = new JButton("OK");
        JButton cancelButton = new JButton("Cancel");

        okButton.addActionListener(e -> {
            confirmed = true;
            setVisible(false);
        });

        cancelButton.addActionListener(e -> {
            confirmed = false;
            setVisible(false);
        });

        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    public int getRefreshInterval() {
        return refreshInterval;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
