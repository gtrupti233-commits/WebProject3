package com.example.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.example.model.EnergyReading;
import com.example.util.DBConnection;

/**
 * Simulator class to generate advanced energy readings with variable load and anomalies.
 */
public class EnergySimulator implements Runnable {
    private static final Logger logger = LogManager.getLogger(EnergySimulator.class);
    private volatile boolean running = false;
    private Thread thread;
    private final String[] zones = {"Production", "Packaging", "Assembly", "Warehouse", "Office"};
    private final Random random = new Random();

    /**
     * Starts the simulation.
     */
    public void startSimulation() {
        if (!running) {
            running = true;
            thread = new Thread(this);
            thread.start();
            logger.info("Energy simulation started");
        }
    }

    /**
     * Stops the simulation.
     */
    public void stopSimulation() {
        running = false;
        if (thread != null) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                logger.error("Error stopping simulation", e);
            }
        }
        logger.info("Energy simulation stopped");
    }

    @Override
    public void run() {
        while (running) {
            try {
                // Generate reading for a random zone
                String zone = zones[random.nextInt(zones.length)];
                double baseUsage = calculateBaseUsage(zone);
                double usage = baseUsage + random.nextDouble() * 100; // Add some variation

                // Introduce anomalies
                if (random.nextDouble() < 0.1) { // 10% chance of anomaly
                    if (random.nextBoolean()) {
                        usage += 200 + random.nextDouble() * 400; // Spike
                        logAnomaly(zone, "spike", usage);
                        logger.warn("Energy spike detected in {}: {} kWh", zone, usage);
                    } else {
                        usage = 0; // Failure
                        logAnomaly(zone, "failure", usage);
                        logger.warn("Power failure detected in {}", zone);
                    }
                }

                EnergyReading reading = new EnergyReading(zone, usage);
                saveReading(reading);

                // Wait 5 seconds
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    /**
     * Calculates base usage based on time of day and zone.
     * @param zone the zone name
     * @return base usage
     */
    private double calculateBaseUsage(String zone) {
        Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        double base = 200; // Base usage

        // Time-based load: higher during day (8-18), lower at night
        if (hour >= 8 && hour <= 18) {
            base *= 1.5; // Day time multiplier
        } else {
            base *= 0.5; // Night time multiplier
        }

        // Zone-specific multipliers
        switch (zone) {
            case "Production": base *= 2.0; break;
            case "Packaging": base *= 1.5; break;
            case "Assembly": base *= 1.8; break;
            case "Warehouse": base *= 1.2; break;
            case "Office": base *= 0.8; break;
        }

        return base;
    }

    /**
     * Logs anomaly to database.
     * @param zone the zone
     * @param type the anomaly type
     * @param usage the usage value
     */
    private void logAnomaly(String zone, String type, double usage) {
        String sql = "INSERT INTO energy_anomalies (zone_name, anomaly_type, energy_usage) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, zone);
            stmt.setString(2, type);
            stmt.setDouble(3, usage);
            stmt.executeUpdate();
        } catch (SQLException e) {
            logger.error("Failed to log anomaly", e);
        }
    }

    /**
     * Saves the energy reading to the database.
     * @param reading the reading to save
     */
    private void saveReading(EnergyReading reading) {
        String sql = "INSERT INTO energy_readings (zone_name, energy_usage) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, reading.getZoneName());
            stmt.setDouble(2, reading.getEnergyUsage());
            stmt.executeUpdate();
        } catch (SQLException e) {
            logger.error("Failed to save energy reading", e);
        }
    }
}
