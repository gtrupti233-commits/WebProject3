package com.example.model;

import java.sql.Timestamp;

/**
 * Model class representing an energy reading.
 */
public class EnergyReading {
    private int id;
    private String zoneName;
    private double energyUsage;
    private Timestamp timestamp;

    public EnergyReading() {}

    public EnergyReading(String zoneName, double energyUsage) {
        this.zoneName = zoneName;
        this.energyUsage = energyUsage;
        this.timestamp = new Timestamp(System.currentTimeMillis());
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getZoneName() { return zoneName; }
    public void setZoneName(String zoneName) { this.zoneName = zoneName; }

    public double getEnergyUsage() { return energyUsage; }
    public void setEnergyUsage(double energyUsage) { this.energyUsage = energyUsage; }

    public Timestamp getTimestamp() { return timestamp; }
    public void setTimestamp(Timestamp timestamp) { this.timestamp = timestamp; }

    @Override
    public String toString() {
        return "EnergyReading{" +
                "id=" + id +
                ", zoneName='" + zoneName + '\'' +
                ", energyUsage=" + energyUsage +
                ", timestamp=" + timestamp +
                '}';
    }
}
