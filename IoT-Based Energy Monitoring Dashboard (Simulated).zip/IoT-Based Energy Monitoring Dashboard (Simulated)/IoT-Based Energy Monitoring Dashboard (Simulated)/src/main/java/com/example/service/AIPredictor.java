package com.example.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.example.util.DBConnection;

/**
 * Enhanced AI predictor for next hour's energy usage using linear regression with accuracy.
 */
public class AIPredictor {
    private static final Logger logger = LogManager.getLogger(AIPredictor.class);

    /**
     * Predicts the next energy usage based on last 20 readings using linear regression.
     * @param zone the zone name
     * @return predicted usage
     */
    public static double predictNextUsage(String zone) {
        List<Double> usages = getLastUsages(zone, 20);
        if (usages.isEmpty()) return 0.0;
        if (usages.size() < 2) return usages.get(0);

        // Linear regression
        double sumX = 0, sumY = 0, sumXY = 0, sumXX = 0, sumYY = 0;
        int n = usages.size();
        for (int i = 0; i < n; i++) {
            double x = i;
            double y = usages.get(i);
            sumX += x;
            sumY += y;
            sumXY += x * y;
            sumXX += x * x;
            sumYY += y * y;
        }

        double m = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
        double c = (sumY - m * sumX) / n;

        // Predict next (n+1)
        double prediction = m * n + c;
        logger.info("Predicted usage for {}: {} kWh", zone, prediction);
        return prediction;
    }

    /**
     * Calculates prediction accuracy using R-squared.
     * @param zone the zone name
     * @return accuracy percentage
     */
    public static double getPredictionAccuracy(String zone) {
        List<Double> usages = getLastUsages(zone, 20);
        if (usages.size() < 3) return 0.0;

        // Calculate R-squared
        double sumX = 0, sumY = 0, sumXY = 0, sumXX = 0, sumYY = 0;
        int n = usages.size();
        for (int i = 0; i < n; i++) {
            double x = i;
            double y = usages.get(i);
            sumX += x;
            sumY += y;
            sumXY += x * y;
            sumXX += x * x;
            sumYY += y * y;
        }

        double m = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
        double c = (sumY - m * sumX) / n;

        double ssRes = 0, ssTot = 0;
        double meanY = sumY / n;
        for (int i = 0; i < n; i++) {
            double x = i;
            double y = usages.get(i);
            double predicted = m * x + c;
            ssRes += (y - predicted) * (y - predicted);
            ssTot += (y - meanY) * (y - meanY);
        }

        double rSquared = 1 - (ssRes / ssTot);
        return Math.max(0, Math.min(100, rSquared * 100)); // Clamp to 0-100%
    }

    /**
     * Gets the last n energy usages for a zone.
     * @param zone the zone
     * @param n number of readings
     * @return list of usages
     */
    private static List<Double> getLastUsages(String zone, int n) {
        List<Double> usages = new ArrayList<>();
        String sql = "SELECT energy_usage FROM energy_readings WHERE zone_name = ? ORDER BY timestamp DESC LIMIT ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, zone);
            stmt.setInt(2, n);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                usages.add(rs.getDouble("energy_usage"));
            }
        } catch (SQLException e) {
            logger.error("Failed to get last usages", e);
        }
        return usages;
    }
}
