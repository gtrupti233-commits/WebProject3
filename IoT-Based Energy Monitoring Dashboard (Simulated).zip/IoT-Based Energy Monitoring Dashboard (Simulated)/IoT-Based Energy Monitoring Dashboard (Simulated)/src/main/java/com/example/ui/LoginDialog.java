package com.example.ui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.example.service.LoginSystem;

/**
 * Login dialog for authentication.
 */
public class LoginDialog extends JDialog {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginDialog() {
        setTitle("Login");
        setSize(400, 300);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setModal(true);

        // Header
        JLabel headerLabel = new JLabel("IoT-Based Energy Monitoring Dashboard", JLabel.CENTER);
        add(headerLabel, BorderLayout.NORTH);

        // Center panel for form
        JPanel centerPanel = new JPanel(new GridLayout(3, 2));
        centerPanel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        centerPanel.add(usernameField);

        centerPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        centerPanel.add(passwordField);

        add(centerPanel, BorderLayout.CENTER);

        // Bottom panel for buttons
        JPanel buttonPanel = new JPanel(new GridLayout(1, 3));
        JButton adminLoginBtn = new JButton("Admin Login");
        JButton userLoginBtn = new JButton("User Login");
        JButton signUpBtn = new JButton("Sign Up");

        buttonPanel.add(adminLoginBtn);
        buttonPanel.add(userLoginBtn);
        buttonPanel.add(signUpBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        adminLoginBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String role = LoginSystem.authenticate(username, password);
                if ("admin".equals(role)) {
                    new DashboardGUI(role);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(LoginDialog.this, "Invalid admin credentials");
                }
            }
        });

        userLoginBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String role = LoginSystem.authenticate(username, password);
                if ("user".equals(role)) {
                    new DashboardGUI(role);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(LoginDialog.this, "Invalid user credentials");
                }
            }
        });

        signUpBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showSignUpDialog();
            }
        });
    }

    private void showSignUpDialog() {
        JDialog signUpDialog = new JDialog(this, "Sign Up", true);
        signUpDialog.setSize(300, 200);
        signUpDialog.setLayout(new GridLayout(4, 2));

        JTextField newUsernameField = new JTextField();
        JPasswordField newPasswordField = new JPasswordField();
        JComboBox<String> roleCombo = new JComboBox<>(new String[]{"user"});

        signUpDialog.add(new JLabel("Username:"));
        signUpDialog.add(newUsernameField);
        signUpDialog.add(new JLabel("Password:"));
        signUpDialog.add(newPasswordField);
        signUpDialog.add(new JLabel("Role:"));
        signUpDialog.add(roleCombo);

        JButton registerBtn = new JButton("Register");
        JButton cancelRegBtn = new JButton("Cancel");
        signUpDialog.add(registerBtn);
        signUpDialog.add(cancelRegBtn);

        registerBtn.addActionListener(e -> {
            String username = newUsernameField.getText();
            String password = new String(newPasswordField.getPassword());
            String role = (String) roleCombo.getSelectedItem();
            if (LoginSystem.registerUser(username, password, role)) {
                JOptionPane.showMessageDialog(signUpDialog, "User registered successfully!");
                signUpDialog.dispose();
            } else {
                JOptionPane.showMessageDialog(signUpDialog, "Registration failed. Username may already exist.");
            }
        });

        cancelRegBtn.addActionListener(e -> signUpDialog.dispose());

        signUpDialog.setVisible(true);
    }
}
