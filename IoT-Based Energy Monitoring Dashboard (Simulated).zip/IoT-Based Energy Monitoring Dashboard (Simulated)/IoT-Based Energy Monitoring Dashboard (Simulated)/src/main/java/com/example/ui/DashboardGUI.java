package com.example.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import com.example.service.AIPredictor;
import com.example.service.EnergySimulator;
import com.example.service.ReportExporter;
import com.example.util.DBConnection;

/**
 * Main dashboard GUI using Swing with modern design.
 */
@SuppressWarnings("unused")
public class DashboardGUI extends JFrame {
    private EnergySimulator simulator = new EnergySimulator();
    private JTable table;
    private DefaultTableModel tableModel;
    private ChartPanel chartPanel;
    private JLabel alertLabel;
    private Timer refreshTimer;
    private boolean isDarkMode = false;
    private int refreshInterval = 5; // in seconds

    // Colors
    private final Color PRIMARY = new Color(0, 120, 215); // #0078D7
    private final Color BACKGROUND_LIGHT = new Color(245, 247, 250); // #F5F7FA
    private final Color ACCENT = new Color(108, 99, 255); // #6C63FF
    private final Color TEXT_LIGHT = new Color(45, 45, 45); // #2D2D2D
    private final Color BACKGROUND_DARK = new Color(30, 30, 30);
    private final Color TEXT_DARK = new Color(220, 220, 220);
    private final Color CARD_BACKGROUND_LIGHT = Color.WHITE;
    private final Color CARD_BACKGROUND_DARK = new Color(45, 45, 45);

    // Fonts
    private final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 18);
    private final Font BUTTON_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    private final Font TEXT_FONT = new Font("Segoe UI", Font.PLAIN, 12);

    // Components
    private JPanel sidebar;
    private JPanel mainContent;
    private JPanel header;
    private JPanel footer;
    private JButton dashboardBtn, liveDataBtn, reportsBtn, aiPredictionBtn, settingsBtn, logoutBtn;
    private JButton startBtn, stopBtn, predictBtn, darkModeBtn, filterBtn;
    private JTabbedPane tabbedPane;
    private ChartPanel barChartPanel, pieChartPanel;

    public DashboardGUI(String role) {
        setTitle("IoT Energy Monitoring Dashboard");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setBackground(BACKGROUND_LIGHT);

        // Set font for all components
        UIManager.put("Label.font", TEXT_FONT);
        UIManager.put("Button.font", BUTTON_FONT);

        // Header
        createHeader();

        // Sidebar
        createSidebar(role);

        // Main Content
        createMainContent();

        // Footer
        createFooter();

        // Refresh timer
        refreshTimer = new Timer();
        refreshTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                refreshData();
            }
        }, 0, refreshInterval * 1000L); // Use configurable interval

        setVisible(true);
    }

    private void refreshData() {
        SwingUtilities.invokeLater(() -> {
            // Refresh table
            tableModel.setRowCount(0);
            String sql = "SELECT * FROM energy_readings ORDER BY timestamp DESC LIMIT 20";
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                while (rs.next()) {
                    tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("zone_name"),
                        rs.getDouble("energy_usage"),
                        rs.getTimestamp("timestamp")
                    });
                    // Check for alerts
                    if (rs.getDouble("energy_usage") > 450) {
                        alertLabel.setText("ALERT: High usage in " + rs.getString("zone_name"));
                    }
                    // Update chart dataset
                    dataset.addValue(rs.getDouble("energy_usage"), rs.getString("zone_name"), rs.getTimestamp("timestamp").toString());
                }
                // Update chart
                JFreeChart chart = ChartFactory.createLineChart("Energy Trends", "Time", "Usage", dataset);
                chartPanel.setChart(chart);
            } catch (SQLException e) {
                e.printStackTrace();
                alertLabel.setText("Error refreshing data: " + e.getMessage());
            }
        });
    }

    private void showPrediction() {
        double predProd = AIPredictor.predictNextUsage("Production");
        double predPack = AIPredictor.predictNextUsage("Packaging");
        double predAss = AIPredictor.predictNextUsage("Assembly");
        double predWare = AIPredictor.predictNextUsage("Warehouse");
        double predOff = AIPredictor.predictNextUsage("Office");

        double accProd = AIPredictor.getPredictionAccuracy("Production");
        double accPack = AIPredictor.getPredictionAccuracy("Packaging");
        double accAss = AIPredictor.getPredictionAccuracy("Assembly");
        double accWare = AIPredictor.getPredictionAccuracy("Warehouse");
        double accOff = AIPredictor.getPredictionAccuracy("Office");

        JOptionPane.showMessageDialog(this,
            "Predicted Usage (with accuracy):\n" +
            "Production: " + String.format("%.2f", predProd) + " kWh (" + String.format("%.1f", accProd) + "%)\n" +
            "Packaging: " + String.format("%.2f", predPack) + " kWh (" + String.format("%.1f", accPack) + "%)\n" +
            "Assembly: " + String.format("%.2f", predAss) + " kWh (" + String.format("%.1f", accAss) + "%)\n" +
            "Warehouse: " + String.format("%.2f", predWare) + " kWh (" + String.format("%.1f", accWare) + "%)\n" +
            "Office: " + String.format("%.2f", predOff) + " kWh (" + String.format("%.1f", accOff) + "%)");
    }



    private void filterByDate() {
        String dateStr = JOptionPane.showInputDialog(this, "Enter date (YYYY-MM-DD):");
        if (dateStr != null && !dateStr.trim().isEmpty()) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date date = sdf.parse(dateStr);
                String sql = "SELECT * FROM energy_readings WHERE DATE(timestamp) = ? ORDER BY timestamp DESC";
                try (Connection conn = DBConnection.getConnection();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setDate(1, new java.sql.Date(date.getTime()));
                    ResultSet rs = stmt.executeQuery();
                    tableModel.setRowCount(0);
                    DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                    while (rs.next()) {
                        tableModel.addRow(new Object[]{
                            rs.getInt("id"),
                            rs.getString("zone_name"),
                            rs.getDouble("energy_usage"),
                            rs.getTimestamp("timestamp")
                        });
                        dataset.addValue(rs.getDouble("energy_usage"), rs.getString("zone_name"), rs.getTimestamp("timestamp").toString());
                    }
                    JFreeChart chart = ChartFactory.createLineChart("Energy Trends", "Time", "Usage", dataset);
                    chartPanel.setChart(chart);
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Error filtering data: " + e.getMessage());
                }
            } catch (ParseException e) {
                JOptionPane.showMessageDialog(this, "Invalid date format. Use YYYY-MM-DD.");
            }
        }
    }

    private void logout() {
        int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            refreshTimer.cancel();
            dispose();
            new LoginDialog().setVisible(true);
        }
    }

    private void createHeader() {
        header = new JPanel(new BorderLayout());
        header.setBackground(isDarkMode ? BACKGROUND_DARK : BACKGROUND_LIGHT);
        header.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel titleLabel = new JLabel("IoT-Based Energy Monitoring Dashboard");
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setForeground(isDarkMode ? TEXT_DARK : TEXT_LIGHT);

        // User icon (simple text for now, can be replaced with icon)
        JLabel userIcon = new JLabel("👤");
        userIcon.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        userIcon.setForeground(PRIMARY);

        header.add(titleLabel, BorderLayout.WEST);
        header.add(userIcon, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);
    }

    private void createSidebar(String role) {
        sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(isDarkMode ? BACKGROUND_DARK : BACKGROUND_LIGHT);
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        sidebar.setPreferredSize(new Dimension(200, 0));

        // Sidebar buttons
        dashboardBtn = createSidebarButton("Dashboard");
        liveDataBtn = createSidebarButton("Live Data");
        reportsBtn = createSidebarButton("Reports");
        aiPredictionBtn = createSidebarButton("AI Prediction");
        settingsBtn = createSidebarButton("Settings");
        logoutBtn = createSidebarButton("Logout");

        // Add buttons to sidebar
        sidebar.add(dashboardBtn);
        sidebar.add(Box.createVerticalStrut(10));
        sidebar.add(liveDataBtn);
        sidebar.add(Box.createVerticalStrut(10));
        sidebar.add(reportsBtn);
        sidebar.add(Box.createVerticalStrut(10));
        sidebar.add(aiPredictionBtn);
        sidebar.add(Box.createVerticalStrut(10));
        sidebar.add(settingsBtn);
        sidebar.add(Box.createVerticalStrut(20));
        sidebar.add(logoutBtn);

        // Event listeners for sidebar buttons
        dashboardBtn.addActionListener(e -> showDashboard());
        liveDataBtn.addActionListener(e -> showLiveData());
        reportsBtn.addActionListener(e -> showReports());
        aiPredictionBtn.addActionListener(e -> showPrediction());
        settingsBtn.addActionListener(e -> showSettings());
        logoutBtn.addActionListener(e -> logout());

        add(sidebar, BorderLayout.WEST);
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton(text);
        button.setFont(BUTTON_FONT);
        button.setForeground(isDarkMode ? TEXT_DARK : TEXT_LIGHT);
        button.setBackground(isDarkMode ? CARD_BACKGROUND_DARK : CARD_BACKGROUND_LIGHT);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(PRIMARY, 1, true),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(PRIMARY);
                button.setForeground(Color.WHITE);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(isDarkMode ? CARD_BACKGROUND_DARK : CARD_BACKGROUND_LIGHT);
                button.setForeground(isDarkMode ? TEXT_DARK : TEXT_LIGHT);
            }
        });

        return button;
    }

    private void createMainContent() {
        mainContent = new JPanel(new BorderLayout());
        mainContent.setBackground(isDarkMode ? BACKGROUND_DARK : BACKGROUND_LIGHT);
        mainContent.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Tabbed pane for different views
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(TEXT_FONT);
        tabbedPane.setBackground(isDarkMode ? CARD_BACKGROUND_DARK : CARD_BACKGROUND_LIGHT);
        tabbedPane.setForeground(isDarkMode ? TEXT_DARK : TEXT_LIGHT);

        // Overview tab
        JPanel overviewPanel = createOverviewPanel();
        tabbedPane.addTab("Overview", overviewPanel);

        // Charts tab
        JPanel chartsPanel = createChartsPanel();
        tabbedPane.addTab("Charts", chartsPanel);

        // Details tab
        JPanel detailsPanel = createDetailsPanel();
        tabbedPane.addTab("Details", detailsPanel);

        mainContent.add(tabbedPane, BorderLayout.CENTER);

        add(mainContent, BorderLayout.CENTER);
    }

    private JPanel createOverviewPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(isDarkMode ? BACKGROUND_DARK : BACKGROUND_LIGHT);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Cards for metrics
        JPanel card1 = createMetricCard("Total Energy Usage", "1,250 kWh", "Today");
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 1;
        panel.add(card1, gbc);

        JPanel card2 = createMetricCard("Active Zones", "5", "Current");
        gbc.gridx = 1; gbc.gridy = 0;
        panel.add(card2, gbc);

        JPanel card3 = createMetricCard("Alerts", "2", "High Usage");
        gbc.gridx = 2; gbc.gridy = 0;
        panel.add(card3, gbc);

        // Line chart
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        JFreeChart chart = ChartFactory.createLineChart("Energy Trends", "Time", "Usage (kWh)", dataset);
        chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(600, 300));
        chartPanel.setBackground(isDarkMode ? CARD_BACKGROUND_DARK : CARD_BACKGROUND_LIGHT);
        chartPanel.setBorder(BorderFactory.createLineBorder(ACCENT, 1, true));
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 3; gbc.fill = GridBagConstraints.BOTH;
        panel.add(chartPanel, gbc);

        // Control buttons
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controlPanel.setBackground(isDarkMode ? BACKGROUND_DARK : BACKGROUND_LIGHT);

        startBtn = createStyledButton("Start Simulation");
        stopBtn = createStyledButton("Stop Simulation");
        predictBtn = createStyledButton("Predict Next Hour");
        darkModeBtn = createStyledButton("Toggle Dark Mode");
        filterBtn = createStyledButton("Filter by Date");

        controlPanel.add(startBtn);
        controlPanel.add(stopBtn);
        controlPanel.add(predictBtn);
        controlPanel.add(darkModeBtn);
        controlPanel.add(filterBtn);

        alertLabel = new JLabel("No alerts");
        alertLabel.setFont(TEXT_FONT);
        alertLabel.setForeground(Color.RED);
        controlPanel.add(alertLabel);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 3; gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(controlPanel, gbc);

        // Event listeners
        startBtn.addActionListener(e -> simulator.startSimulation());
        stopBtn.addActionListener(e -> simulator.stopSimulation());
        predictBtn.addActionListener(e -> showPrediction());
        darkModeBtn.addActionListener(e -> toggleDarkMode());
        filterBtn.addActionListener(e -> filterByDate());

        return panel;
    }

    private JPanel createChartsPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(isDarkMode ? BACKGROUND_DARK : BACKGROUND_LIGHT);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Bar chart
        DefaultCategoryDataset barDataset = new DefaultCategoryDataset();
        JFreeChart barChart = ChartFactory.createBarChart("Average Energy Usage per Zone", "Zone", "Usage (kWh)", barDataset, PlotOrientation.VERTICAL, true, true, false);
        barChartPanel = new ChartPanel(barChart);
        barChartPanel.setPreferredSize(new Dimension(400, 300));
        barChartPanel.setBackground(isDarkMode ? CARD_BACKGROUND_DARK : CARD_BACKGROUND_LIGHT);
        barChartPanel.setBorder(BorderFactory.createLineBorder(ACCENT, 1, true));
        gbc.gridx = 0; gbc.gridy = 0; gbc.fill = GridBagConstraints.BOTH;
        panel.add(barChartPanel, gbc);

        // Pie chart
        DefaultPieDataset pieDataset = new DefaultPieDataset();
        JFreeChart pieChart = ChartFactory.createPieChart("Usage Distribution", pieDataset, true, true, false);
        pieChartPanel = new ChartPanel(pieChart);
        pieChartPanel.setPreferredSize(new Dimension(400, 300));
        pieChartPanel.setBackground(isDarkMode ? CARD_BACKGROUND_DARK : CARD_BACKGROUND_LIGHT);
        pieChartPanel.setBorder(BorderFactory.createLineBorder(ACCENT, 1, true));
        gbc.gridx = 1; gbc.gridy = 0;
        panel.add(pieChartPanel, gbc);

        return panel;
    }

    private JPanel createDetailsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(isDarkMode ? BACKGROUND_DARK : BACKGROUND_LIGHT);

        // Table
        tableModel = new DefaultTableModel(new String[]{"ID", "Zone", "Usage (kWh)", "Timestamp"}, 0);
        table = new JTable(tableModel);
        table.setFont(TEXT_FONT);
        table.setBackground(isDarkMode ? CARD_BACKGROUND_DARK : CARD_BACKGROUND_LIGHT);
        table.setForeground(isDarkMode ? TEXT_DARK : TEXT_LIGHT);
        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createLineBorder(ACCENT, 1, true));
        panel.add(tableScroll, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createMetricCard(String title, String value, String subtitle) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(isDarkMode ? CARD_BACKGROUND_DARK : CARD_BACKGROUND_LIGHT);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(ACCENT, 1, true),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        card.setPreferredSize(new Dimension(200, 100));

        // Soft shadow effect
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createRaisedBevelBorder(),
            card.getBorder()
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(TEXT_FONT);
        titleLabel.setForeground(isDarkMode ? TEXT_DARK : TEXT_LIGHT);

        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        valueLabel.setForeground(PRIMARY);

        JLabel subtitleLabel = new JLabel(subtitle);
        subtitleLabel.setFont(TEXT_FONT);
        subtitleLabel.setForeground(Color.GRAY);

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        card.add(subtitleLabel, BorderLayout.SOUTH);

        return card;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(BUTTON_FONT);
        button.setForeground(isDarkMode ? TEXT_DARK : TEXT_LIGHT);
        button.setBackground(PRIMARY);
        button.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Rounded border
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(PRIMARY, 1, true),
            BorderFactory.createEmptyBorder(8, 16, 8, 16)
        ));

        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(ACCENT);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(PRIMARY);
            }
        });

        return button;
    }

    private void createFooter() {
        footer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footer.setBackground(isDarkMode ? BACKGROUND_DARK : BACKGROUND_LIGHT);
        footer.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel footerLabel = new JLabel("© 2024 IoT Energy Monitoring Dashboard. All rights reserved.");
        footerLabel.setFont(TEXT_FONT);
        footerLabel.setForeground(isDarkMode ? TEXT_DARK : TEXT_LIGHT);

        footer.add(footerLabel);
        add(footer, BorderLayout.SOUTH);
    }

    private void showDashboard() {
        // Already on dashboard
        JOptionPane.showMessageDialog(this, "Already on Dashboard");
    }

    private void showLiveData() {
        LiveDataSettingsDialog dialog = new LiveDataSettingsDialog(this, refreshInterval);
        dialog.setVisible(true);
        if (dialog.isConfirmed()) {
            int newInterval = dialog.getRefreshInterval();
            if (newInterval != refreshInterval) {
                refreshInterval = newInterval;
                // Restart timer with new interval
                refreshTimer.cancel();
                refreshTimer = new Timer();
                refreshTimer.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        refreshData();
                    }
                }, 0, refreshInterval * 1000L);
                JOptionPane.showMessageDialog(this, "Refresh interval updated to " + refreshInterval + " seconds.");
            }
        }
    }

    private void showReports() {
        ReportExporter.exportToCSV("report.csv");
        ReportExporter.exportToExcel("report.xlsx");
        JOptionPane.showMessageDialog(this, "Reports exported to CSV and Excel");
    }

    private void showSettings() {
        JOptionPane.showMessageDialog(this, "Settings - Feature coming soon");
    }

    public void toggleDarkMode() {
        isDarkMode = !isDarkMode;

        // Update colors
        Color bg = isDarkMode ? BACKGROUND_DARK : BACKGROUND_LIGHT;
        Color fg = isDarkMode ? TEXT_DARK : TEXT_LIGHT;
        Color cardBg = isDarkMode ? CARD_BACKGROUND_DARK : CARD_BACKGROUND_LIGHT;

        // Update main components
        getContentPane().setBackground(bg);
        header.setBackground(bg);
        sidebar.setBackground(bg);
        mainContent.setBackground(bg);
        footer.setBackground(bg);

        // Update header
        for (Component c : header.getComponents()) {
            if (c instanceof JLabel) {
                c.setForeground(fg);
            }
        }

        // Update sidebar buttons
        for (Component c : sidebar.getComponents()) {
            if (c instanceof JButton) {
                JButton btn = (JButton) c;
                btn.setBackground(cardBg);
                btn.setForeground(fg);
            }
        }

        // Update main content
        for (Component c : mainContent.getComponents()) {
            if (c instanceof JPanel) {
                updatePanelColors((JPanel) c, bg, fg, cardBg);
            }
        }

        // Update table
        table.setBackground(cardBg);
        table.setForeground(fg);

        repaint();
    }

    private void updatePanelColors(JPanel panel, Color bg, Color fg, Color cardBg) {
        panel.setBackground(bg);
        for (Component c : panel.getComponents()) {
            if (c instanceof JLabel) {
                c.setForeground(fg);
            } else if (c instanceof JButton) {
                JButton btn = (JButton) c;
                btn.setBackground(PRIMARY);
                btn.setForeground(Color.WHITE);
            } else if (c instanceof JPanel) {
                JPanel subPanel = (JPanel) c;
                subPanel.setBackground(cardBg);
                for (Component subC : subPanel.getComponents()) {
                    if (subC instanceof JLabel) {
                        subC.setForeground(fg);
                    }
                }
            }
        }
    }
}
