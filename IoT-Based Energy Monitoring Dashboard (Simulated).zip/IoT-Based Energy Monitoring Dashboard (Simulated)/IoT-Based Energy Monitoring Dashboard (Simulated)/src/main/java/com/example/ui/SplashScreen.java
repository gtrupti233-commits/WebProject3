package com.example.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JWindow;
import javax.swing.SwingConstants;

/**
 * Splash screen for application loading.
 */
public class SplashScreen extends JWindow {
    private JProgressBar progressBar;
    private JLabel messageLabel;

    public SplashScreen() {
        setSize(400, 300);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);

        JLabel titleLabel = new JLabel("IoT Energy Monitoring Dashboard", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(titleLabel, BorderLayout.NORTH);

        messageLabel = new JLabel("Loading...", SwingConstants.CENTER);
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(messageLabel, BorderLayout.CENTER);

        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        panel.add(progressBar, BorderLayout.SOUTH);

        add(panel);
        setVisible(true);
    }

    public void setProgress(int progress, String message) {
        progressBar.setValue(progress);
        messageLabel.setText(message);
    }

    public void close() {
        setVisible(false);
        dispose();
    }
}
