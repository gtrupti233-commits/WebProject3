package com.example.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

import com.example.util.DBConnection;

/**
 * Enhanced class for exporting energy reports to CSV, Excel, and PDF with summaries.
 */
public class ReportExporter {
    private static final Logger logger = LogManager.getLogger(ReportExporter.class);

    /**
     * Exports energy readings to CSV with summary.
     * @param filePath the file path
     */
    public static void exportToCSV(String filePath) {
        try (Connection conn = DBConnection.getConnection();
             FileOutputStream fos = new FileOutputStream(filePath)) {

            StringBuilder csv = new StringBuilder();
            csv.append("Energy Monitoring Report\n\n");

            // Add summary
            addSummaryToReport(csv, conn);

            csv.append("\nDetailed Readings:\n");
            csv.append("ID,Zone Name,Energy Usage,Timestamp\n");

            String sql = "SELECT * FROM energy_readings ORDER BY timestamp DESC";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    csv.append(rs.getInt("id")).append(",")
                        .append(rs.getString("zone_name")).append(",")
                        .append(rs.getDouble("energy_usage")).append(",")
                        .append(rs.getTimestamp("timestamp")).append("\n");
                }
            }

            fos.write(csv.toString().getBytes());
            logger.info("CSV report exported to {}", filePath);
        } catch (SQLException | IOException e) {
            logger.error("Error exporting to CSV", e);
        }
    }

    /**
     * Exports energy readings to Excel with analytics.
     * @param filePath the file path
     */
    public static void exportToExcel(String filePath) {
        try (Connection conn = DBConnection.getConnection();
             Workbook workbook = new XSSFWorkbook();
             FileOutputStream fos = new FileOutputStream(filePath)) {

            // Summary sheet
            Sheet summarySheet = workbook.createSheet("Summary");
            addSummaryToExcel(summarySheet, conn);

            // Data sheet
            Sheet dataSheet = workbook.createSheet("Data");
            Row headerRow = dataSheet.createRow(0);
            headerRow.createCell(0).setCellValue("ID");
            headerRow.createCell(1).setCellValue("Zone Name");
            headerRow.createCell(2).setCellValue("Energy Usage");
            headerRow.createCell(3).setCellValue("Timestamp");

            String sql = "SELECT * FROM energy_readings ORDER BY timestamp DESC";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                int rowNum = 1;
                while (rs.next()) {
                    Row row = dataSheet.createRow(rowNum++);
                    row.createCell(0).setCellValue(rs.getInt("id"));
                    row.createCell(1).setCellValue(rs.getString("zone_name"));
                    row.createCell(2).setCellValue(rs.getDouble("energy_usage"));
                    row.createCell(3).setCellValue(rs.getTimestamp("timestamp").toString());
                }
            }

            workbook.write(fos);
            logger.info("Excel report exported to {}", filePath);
        } catch (SQLException | IOException e) {
            logger.error("Error exporting to Excel", e);
        }
    }

    /**
     * Exports energy readings to PDF (DOCX) with enhanced summary.
     * @param filePath the file path
     */
    public static void exportToPDF(String filePath) {
        try (Connection conn = DBConnection.getConnection();
             XWPFDocument document = new XWPFDocument();
             FileOutputStream fos = new FileOutputStream(filePath)) {

            XWPFParagraph titlePara = document.createParagraph();
            XWPFRun titleRun = titlePara.createRun();
            titleRun.setText("Energy Monitoring Report");
            titleRun.setBold(true);
            titleRun.setFontSize(16);

            // Add summary
            addSummaryToWord(document, conn);

            XWPFParagraph dataPara = document.createParagraph();
            XWPFRun dataRun = dataPara.createRun();
            dataRun.setText("\nDetailed Readings:\n");

            String sql = "SELECT * FROM energy_readings ORDER BY timestamp DESC";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    XWPFParagraph para = document.createParagraph();
                    XWPFRun run = para.createRun();
                    run.setText("ID: " + rs.getInt("id") + ", Zone: " + rs.getString("zone_name") +
                                ", Usage: " + rs.getDouble("energy_usage") + ", Time: " + rs.getTimestamp("timestamp"));
                }
            }

            document.write(fos);
            logger.info("PDF report exported to {}", filePath);
        } catch (SQLException | IOException e) {
            logger.error("Error exporting to PDF", e);
        }
    }

    private static void addSummaryToReport(StringBuilder report, Connection conn) throws SQLException {
        String sql = "SELECT zone_name, COUNT(*) as count, AVG(energy_usage) as avg_usage, " +
                     "MIN(energy_usage) as min_usage, MAX(energy_usage) as max_usage " +
                     "FROM energy_readings GROUP BY zone_name";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            report.append("Zone Summary:\n");
            while (rs.next()) {
                report.append(rs.getString("zone_name")).append(": ")
                      .append("Count=").append(rs.getInt("count")).append(", ")
                      .append("Avg=").append(String.format("%.2f", rs.getDouble("avg_usage"))).append(", ")
                      .append("Min=").append(String.format("%.2f", rs.getDouble("min_usage"))).append(", ")
                      .append("Max=").append(String.format("%.2f", rs.getDouble("max_usage"))).append("\n");
            }
        }
    }

    private static void addSummaryToExcel(Sheet sheet, Connection conn) throws SQLException {
        Row titleRow = sheet.createRow(0);
        titleRow.createCell(0).setCellValue("Zone Summary");

        String sql = "SELECT zone_name, COUNT(*) as count, AVG(energy_usage) as avg_usage, " +
                     "MIN(energy_usage) as min_usage, MAX(energy_usage) as max_usage " +
                     "FROM energy_readings GROUP BY zone_name";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            int rowNum = 1;
            while (rs.next()) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(rs.getString("zone_name"));
                row.createCell(1).setCellValue(rs.getInt("count"));
                row.createCell(2).setCellValue(rs.getDouble("avg_usage"));
                row.createCell(3).setCellValue(rs.getDouble("min_usage"));
                row.createCell(4).setCellValue(rs.getDouble("max_usage"));
            }
        }
    }

    private static void addSummaryToWord(XWPFDocument document, Connection conn) throws SQLException {
        XWPFParagraph para = document.createParagraph();
        XWPFRun run = para.createRun();
        run.setText("\nZone Summary:\n");

        String sql = "SELECT zone_name, COUNT(*) as count, AVG(energy_usage) as avg_usage, " +
                     "MIN(energy_usage) as min_usage, MAX(energy_usage) as max_usage " +
                     "FROM energy_readings GROUP BY zone_name";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                XWPFParagraph p = document.createParagraph();
                XWPFRun r = p.createRun();
                r.setText(rs.getString("zone_name") + ": Count=" + rs.getInt("count") +
                          ", Avg=" + String.format("%.2f", rs.getDouble("avg_usage")) +
                          ", Min=" + String.format("%.2f", rs.getDouble("min_usage")) +
                          ", Max=" + String.format("%.2f", rs.getDouble("max_usage")));
            }
        }
    }
}
