package com.example;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.example.ui.LoginDialog;
import com.example.ui.SplashScreen;
import com.formdev.flatlaf.FlatLightLaf;

/**
 * Main class to launch the application.
 */
public class Main { 
    private static final Logger logger = LogManager.getLogger(Main.class);

    public static void main(String[] args) {
        // Set FlatLaf theme
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception e) {
            logger.warn("Failed to set FlatLaf theme, using default", e);
        }

        logger.info("Starting IoT Energy Monitoring Dashboard");

        SwingUtilities.invokeLater(() -> {
            SplashScreen splash = new SplashScreen();
            splash.setProgress(10, "Initializing...");

            // Simulate loading
            new Thread(() -> {
                try {
                    Thread.sleep(1000);
                    splash.setProgress(50, "Loading components...");
                    Thread.sleep(1000);
                    splash.setProgress(90, "Connecting to database...");
                    Thread.sleep(500);
                    splash.setProgress(100, "Ready!");
                    Thread.sleep(500);
                    splash.close();

                    SwingUtilities.invokeLater(() -> {
                        LoginDialog loginDialog = new LoginDialog();
                        loginDialog.setVisible(true);
                    });
                } catch (InterruptedException e) {
                    logger.error("Splash screen interrupted", e);
                }
            }).start();
        });
    }
}


